#include<stdio.h>
main(){
	int i,j,c,found,k,n,pf=0;
	printf("Enter the no of frames: ");
	scanf("%d",&n);
	printf("Enter the no of words in list: ");
	scanf("%d",&k);
	int frames[n],lru[n];
	printf("Enter the list: \n");
	/*for(i=0;i<k;i++){
			scanf("%d",&list[i]);
	}*/
	int list[]={0,1,2,3,2,4,5,1,6,5,2,3,0,1,8};
	for(i=0;i<n;i++){
		c=0;
		for(j=0;j<i;j++){
			if(list[i]==lru[j]){
					c=1;
			}
		}
		if(c==0){
			frames[i]=list[i];
			pf++;
		}
		for(j=0;j<i;j++){
			lru[j]=lru[j+1];
			if(j==n-1)
				break;
		}
		lru[j]=list[i];
	}
	printf("page fault=%d",pf);
	while(i<k){
			c=0;
			for(j=0;j<n;j++){
				if(list[i]==lru[j]){
					c=1;
					found=j;
				}
			}
			if(c==0){
				pf++;
				printf("\n");
				for(j=0;j<n-1;j++){
					lru[j]=lru[j+1];
				}
				lru[j]=list[i];
			}
			else{
				for(j=found;j<n-1;j++){
					lru[j]=lru[j+1];
				}
				lru[j]=list[i];
				i++;
	 		}
	}
	 printf("page fault=%d",pf);
}
	
	 
	 	

