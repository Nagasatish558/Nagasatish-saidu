#include<stdio.h>
main(){
	int i,j;
	for(i=0;i<10;i++){
		printf("%d",i);
		if(i==7)
			break;
	}
	printf("%d",i);
	
}
