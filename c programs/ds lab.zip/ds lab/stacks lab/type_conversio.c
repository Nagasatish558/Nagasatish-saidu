#include<stdio.h>
int main()
{
int i;
i=3;
float j;
j=(int)i;
float k;
k= 2.3/1.2;
i=(int)k;
printf("%f %d",j,i);
return 0;
}
